/**
 * handler.js — Sundial Budget Lambda entry point.
 *
 * Two ways in, one code path:
 *   1. API Gateway (portal "Recalculate Budget" button):
 *      POST /projects/{recordId}/budget/recalc  -> synchronous, returns computed outputs
 *   2. Sundial_Budget_Recalc__e platform event, relayed via EventBridge (field-change
 *      triggers like Audit Completed / Design Review Finalized publish the event from
 *      a record-triggered Flow)
 *
 * Flow: read inputs from Salesforce -> calculate -> update output fields ->
 *       build workbook snapshot -> upload to S3 SUNDIAL/{recordId}/ -> update status fields.
 * The Dropbox mirror picks the file up from S3 through the existing copy-back sync.
 */
const jsforce = require('jsforce');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { calculateBudget } = require('./budgetCalc');
const { buildWorkbook, snapshotKey } = require('./budgetWorkbook');

const s3 = new S3Client({});
const BUCKET = process.env.S3_BUCKET || 'sfsolproj';

// Every input field the calculator reads (kept in one list so the SOQL stays honest)
const INPUT_FIELDS = [
  'Name', 'Project_Name__c', 'Panel_Type__c', 'Contract_Amount__c', 'Dealer_Fee__c',
  'System_Size__c', 'Module_STC_Wattage__c', 'Module_Cost_Per_Watt__c',
  'Sales_Rep_Commission_PPW__c', 'Sales_Mgr_Commission_PPW__c', 'Geo_Commission_Amount__c',
  'Overhead_Commission_PPW__c', 'Commission_Burden_Rate__c',
  'Combiner_Unit_Cost__c', 'Combiner_Qty__c', 'Gateway_Unit_Cost__c', 'Gateway_Qty__c',
  'Microinverter_Unit_Cost__c', 'Microinverter_Qty__c', 'Battery_Unit_Cost__c', 'Battery_Qty__c',
  'BOS_Solar_Cost_Per_Watt__c', 'BOS_Electrical_Cost_Per_Watt__c',
  'Roof_Material_Cost_Per_Pen__c', 'Penetrations_Per_Module__c',
  'Blended_Labor_Rate__c', 'Labor_Burden_Rate__c', 'Audit_Hours__c', 'QA_Commissioning_Hours__c',
  'Roofing_Cost_Per_Penetration__c', 'Roofing_Pens_Per_Module__c', 'Install_Hours_Per_Module__c',
  'Battery_Labor_Rate__c', 'Battery_Install_Hours__c',
  'Material_Other_Cost__c', 'Constructive_Ops_Fee__c', 'Permit_Pass_Through_Cost__c',
  ...['Sub_Panel','Flat_Roof','Bird_Blocking','Derate','Structural','Small_System_10_12','Small_System_13_15','Heat_Detector','Conduit_Attic','Roof_Tile','Software_Fee','Upgrade_225','Upgrade_400']
    .flatMap((b) => [`Adder_${b}_Price__c`, `Adder_${b}_Qty__c`]),
  ...[1, 2, 3].flatMap((n) => [`NS_Adder_${n}_Description__c`, `NS_Adder_${n}_Markup_Percent__c`, `NS_Adder_${n}_Material_Cost__c`, `NS_Adder_${n}_Labor_Hours__c`]),
];

async function sfConnection() {
  // Same JWT bearer pattern as the other Sundial Lambdas (integration user)
  const conn = new jsforce.Connection({ loginUrl: process.env.SF_LOGIN_URL });
  await conn.authorize({
    grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
    // ...org-standard JWT assertion built from SF_CLIENT_ID / SF_USERNAME / private key in Secrets Manager
  });
  return conn;
}

async function recalcOne(conn, recordId, source) {
  const rec = await conn.sobject('Sundial_Solar__c').retrieve(recordId, { fields: INPUT_FIELDS });
  const { fields, cells } = calculateBudget(rec);

  const now = new Date();
  const key = snapshotKey(recordId, rec.Project_Name__c || rec.Name, now);
  const buffer = await buildWorkbook(cells, { recordId, generatedAt: now.toISOString() });

  await s3.send(new PutObjectCommand({
    Bucket: BUCKET, Key: key, Body: buffer,
    ContentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  }));

  await conn.sobject('Sundial_Solar__c').update({
    Id: recordId,
    ...fields,
    Budget_Last_Calculated__c: now.toISOString(),
    Budget_Calc_Status__c: 'Calculated',
    Budget_Calc_Error__c: null,
    Latest_Budget_File_Path__c: key,
  });

  // TODO: register file metadata in Supabase (filename, category 'Budget', size) per file-storage.md
  return { recordId, source, s3Key: key, fields };
}

exports.handler = async (event) => {
  const jobs = [];
  if (event.httpMethod || event.requestContext) {
    // API Gateway: button-triggered synchronous recalc
    const recordId = event.pathParameters?.recordId || JSON.parse(event.body || '{}').recordId;
    jobs.push({ recordId, source: 'Button' });
  } else if (Array.isArray(event.Records)) {
    // SQS-wrapped platform events
    for (const r of event.Records) {
      const payload = JSON.parse(r.body);
      jobs.push({ recordId: payload.Record_Id__c, source: payload.Source__c || 'FieldTrigger' });
    }
  } else if (event.detail) {
    // EventBridge-relayed platform event
    jobs.push({ recordId: event.detail.payload?.Record_Id__c, source: event.detail.payload?.Source__c || 'FieldTrigger' });
  }

  const conn = await sfConnection();
  const results = [];
  for (const j of jobs.filter((x) => x.recordId)) {
    try {
      results.push(await recalcOne(conn, j.recordId, j.source));
    } catch (err) {
      console.error('Budget recalc failed', j.recordId, err);
      try {
        await conn.sobject('Sundial_Solar__c').update({
          Id: j.recordId, Budget_Calc_Status__c: 'Error',
          Budget_Calc_Error__c: String(err.message || err).slice(0, 255),
        });
      } catch (e2) { console.error('Status writeback failed', e2); }
      if (event.httpMethod || event.requestContext) throw err; // surface to the portal
    }
  }

  if (event.httpMethod || event.requestContext) {
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(results[0] || {}) };
  }
  return { processed: results.length };
};
